# waybar_conf
A repo for waybar configs
