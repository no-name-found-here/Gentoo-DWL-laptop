#!/bin/bash
waybar &
swaybg --image ~/Downloads/gentoo_alien.jpg &
wl-clip-persist --clipboard regular &
wl-paste --type text --watch cliphist store &
wl-paste --type image --watch cliphist store &
dunst &
exec /usr/libexec/polkit-gnome-authentication-agent-1
